# Confluent Cloud Clients Library
This library provides a set of clients for interacting with Confluent Cloud. The library includes clients for:
- Schema Registry
- Flink